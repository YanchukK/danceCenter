<?php
/**
 * Created by PhpStorm.
 * User: марк
 * Date: 04.05.2018
 * Time: 6:20
 */

namespace App\Traits;


trait CustomerOwned
{

}