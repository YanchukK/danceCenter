<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="form-group">
    <?php echo Form::text('login', null, ['class' => 'form-control','placeholder' => 'Login', 'required']); ?>

    <br>
    <?php echo Form::text('password', null, ['class' => 'form-control', 'type' => 'password', 'placeholder' => 'Password']); ?>

    <br>
    <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Teacher Name']); ?>

    <br>
    <?php echo Form::text('l_name', null, ['class' => 'form-control', 'placeholder' => 'Last name']); ?>

    <br>
    <?php echo Form::text('email', null, ['class' => 'form-control', 'placeholder' => 'Email']); ?>

    <br>
    <?php echo Form::text('p_number', null, ['class' => 'form-control', 'placeholder' => 'Phone number']); ?>

    <br>
    <div class="form-group">
        <?php echo e(Form::file('teacher_img')); ?>

    </div>
    <p></p>
</div>