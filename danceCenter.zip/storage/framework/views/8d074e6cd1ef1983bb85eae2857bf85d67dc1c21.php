<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Branches</div>
                    
                    
                    
                    
                    
                    <div class="panel-body">
                        <div class="d-flex justify-content-between flex-sm-column flex-md-row flex-wrap">
                            <?php if(Illuminate\Support\Facades\Auth::user()->middleware == '1a'): ?>
                                <?php echo e(link_to_route('group.create', 'Create group', null, ['class' => 'rounded-0 btn btn-outline-info btn-lg btn-block'])); ?>

                            <?php endif; ?>
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="rounded-0 card mt-3" style="width: 22rem;">
                                    <img class="card-img-top"
                                         src="/storage/img/group/<?php echo e($model->group_img); ?>"
                                         alt="Card image cap">
                                    <div class="card-body">
                                        <h4 class="card-title"><?php echo e($model->title); ?></h4>
                                        <div class="card-text">
                                            <?php if($model->notice_id !== NULL): ?>
                                                <hr>
                                                <h4><?php echo e($model->notice->body); ?></h4>
                                                <hr>
                                            <?php endif; ?>
                                            <h6><?php echo e($model->teacher->name); ?> <?php echo e($model->teacher->l_name); ?></h6>
                                            <p><?php echo e($model->style->title); ?></p>
                                            <p><?php echo e($model->branch->title); ?></p>
                                            <p><?php echo e($model->date_time); ?></p>
                                            <p>Cost of single lesson is $<?php echo e($model->price->cost_for_one); ?> </p>
                                        </div>
                                        <div class="d-flex flex-sm-row flex-xs-column justify-content-center">
                                            <?php echo e(link_to_route('group.show', 'View', $model->id, ['class' => 'btn btn-success rounded-0 h-50 px-4'])); ?>

                                            <?php echo e(link_to_route('group.edit', 'Update', $model->id, ['class' => 'btn btn-primary rounded-0 h-50 px-4'])); ?>

                                            <?php echo e(Form::open(['class' => 'confirm-delete', 'route' => ['group.destroy', $model->id], 'method' => 'DELETE'])); ?>

                                            <?php echo e(Form::button('Delete', ['class' => 'btn btn-danger rounded-0 px-4', 'type' => 'submit'])); ?>

                                            <?php echo e(Form::close()); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>