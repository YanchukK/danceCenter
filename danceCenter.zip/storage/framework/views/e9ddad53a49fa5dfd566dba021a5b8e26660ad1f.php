<?php $__env->startSection('content'); ?>

    <section class="news-slider">
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleSlidesOnly" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleSlidesOnly" data-slide-to="1"></li>
                    <li data-target="#carouselExampleSlidesOnly" data-slide-to="2"></li>
                </ol>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->iteration == 1): ?>
                        <div class="carousel-item active">
                            <img class="d-block slider-img" src="/storage/img/news/<?php echo e($model->news_img); ?>"
                                 alt="First slide">
                            <img class="logo-news" src="<?php echo e(asset('img/news/news-logo.png')); ?>" alt="LOGO_NEWS">
                            <div class="carousel-caption d-none d-md-block ns-desc">
                                <h3><?php echo e($model->title); ?></h3>
                                <p><?php echo e($model->desc); ?></p>
                            </div>
                        </div>
                    <?php elseif($loop->iteration == 2): ?>
                        <div class="carousel-item">
                            <img class="d-block slider-img" src="/storage/img/news/<?php echo e($model->news_img); ?>"
                                 alt="First slide">
                            <img class="logo-news" src="<?php echo e(asset('img/news/news-logo.png')); ?>" alt="LOGO_NEWS">
                            <div class="carousel-caption d-none d-md-block ns-desc">
                                <h3><?php echo e($model->title); ?></h3>
                                <p><?php echo e($model->desc); ?></p>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="carousel-item">
                            <img class="d-block slider-img" src="/storage/img/news/<?php echo e($model->news_img); ?>"
                                 alt="First slide">
                            <img class="logo-news" src="<?php echo e(asset('img/news/news-logo.png')); ?>" alt="LOGO_NEWS">
                            <div class="carousel-caption d-none d-md-block ns-desc">
                                <h3><?php echo e($model->title); ?></h3>
                                <p><?php echo e($model->desc); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <section class="styles">
        <div class="styles-review">
            <?php $__currentLoopData = $styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="s-board">
                    <img src="/storage/img/style/<?php echo e($style->style_img); ?>" alt="STYLE">
                    <h1><?php echo e($style->title); ?></h1>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="left-side"></div>
        <div class="right-side">
            <h1>Styles.</h1>
        </div>
    </section>
    <section class="branches">
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->iteration == 1): ?>
                        <div class="carousel-item active">
                            <?php else: ?>
                                <div class="carousel-item">
                                    <?php endif; ?>
                                    <div class="branch-slide">
                                        <div class="left-side">
                                            <h1><?php echo e($branch->name); ?></h1>
                                            <div class="img-block">
                                                <img class="d-block" src="/storage/img/branch/<?php echo e($branch->branch_img); ?>"
                                                     alt="First slide">
                                            </div>
                                        </div>
                                        <div class="right-side">
                                            <div class="r-text-block">
                                                <p class="inner-text"><?php echo e($branch->desc); ?></p>
                                            </div>
                                            <h6>Some text Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab
                                                aut eos
                                                illo quas quo rem saepe tempora ut veniam, voluptate.</h6>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
            </div>
    </section>
    <section class="feedback" id="target">
        <h4>Send your <span>name</span> and <span>email</span> to as, and we invite you to first training for free!
        </h4>
        <?php echo Form::open(['route' => 'customer.store']); ?>

        <div class="form-group feedback-form">
            <?php echo Form::text('name', null, ['class' => 'form-control ff-control', 'placeholder' => ' Name', 'required']); ?>

            <br>
            <?php echo Form::text('email', null, ['class' => 'form-control ff-control', 'placeholder' => 'Email', 'required']); ?>

            <br>
            <?php echo Form::button('Go!', ['type' => 'submit', 'class' => 'btn btn-primary ff-btn']); ?>

        </div>
        <?php echo Form::close(); ?>

    </section>
    <footer>
        ⒸEshkere!
    </footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>