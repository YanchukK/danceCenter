<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Teachers</div>
                    
                    
                    
                    
                    
                    <div class="panel-body">
                        <div class="d-flex justify-content-between flex-sm-column flex-md-row flex-wrap">
                            <?php echo e(link_to_route('teacher.create', 'Create teacher', null, ['class' => 'rounded-0 btn btn-outline-info btn-lg btn-block'])); ?>

                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="rounded-0 card mt-3" style="width: 22rem;">
                                    <img class="card-img-top"
                                         src="/storage/img/teacher/<?php echo e($model->teacher_img); ?>"
                                         alt="Card image cap">
                                    <div class="card-body">
                                        <h4 class="card-title"><?php echo e($model->name); ?> <?php echo e($model->l_name); ?></h4>
                                        <div class="card-text">
                                            <h6><?php echo e($model->login); ?></h6>
                                            <p><?php echo e($model->password); ?></p>
                                            <p><?php echo e($model->email); ?></p>
                                            <p><?php echo e($model->p_number); ?></p>
                                        </div>
                                        <div class="d-flex flex-sm-row flex-xs-column justify-content-center">
                                            <?php echo e(link_to_route('teacher.show', 'View', $model->id, ['class' => 'btn btn-success rounded-0 h-50 px-4'])); ?>

                                            <?php echo e(link_to_route('teacher.edit', 'Update', $model->id, ['class' => 'btn btn-primary rounded-0 h-50 px-4'])); ?>

                                            <?php echo e(Form::open(['class' => 'confirm-delete', 'route' => ['teacher.destroy', $model->id], 'method' => 'DELETE'])); ?>

                                            <?php echo e(Form::button('Delete', ['class' => 'btn btn-danger rounded-0 px-4', 'type' => 'submit'])); ?>

                                            <?php echo e(Form::close()); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>