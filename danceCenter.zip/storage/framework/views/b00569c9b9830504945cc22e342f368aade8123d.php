<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="form-group">
    <?php echo Form::text('desc', null, ['class' => 'form-control', 'method' => 'POST', 'placeholder' => 'branch description', 'required']); ?>

    <br>
    <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => ' name']); ?>

    <br>
    <?php echo Form::text('address', null, ['class' => 'form-control', 'placeholder' => ' address']); ?>

    <br>
    <?php echo Form::text('p_number', null, ['class' => 'form-control', 'placeholder' => ' phone number']); ?>

    <br>
    <?php echo Form::text('w_hours', null, ['class' => 'form-control', 'placeholder' => ' work hours']); ?>

    <br>
    <div class="form-group">
        <?php echo e(Form::file('branch_img')); ?>

    </div>
    <p></p>
</div>