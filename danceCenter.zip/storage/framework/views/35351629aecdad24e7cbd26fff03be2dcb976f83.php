<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center flex-sm-column flex-md-row">
        <h2>Branches</h2>
    </div>
    <div class="d-flex justify-content-center flex-sm-column flex-md-row flex-wrap">
        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card m-3 order-<?php echo e($loop->count); ?>" style="width: 20rem;">
                <img class="card-img-top"
                     src="/storage/img/branch/<?php echo e($model->branch_img); ?>"
                     alt="Card image cap">
                <div class="card-body">
                    <h4 class="card-title"><?php echo e($model->title); ?></h4>
                    <div class="card-text">
                        <h6><?php echo e($model->name); ?></h6>
                        <p><?php echo e($model->address); ?></p>
                        <p><?php echo e($model->p_number); ?></p>
                        <p><?php echo e($model->w_hours); ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>